import React from "react";

class CoursesPage extends React.Component {
  render() {
    return <h2>Courses</h2>;
  }
}

export default CoursesPage;
